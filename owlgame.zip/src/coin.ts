import { get, preload } from "@three.ez/asset-manager";
import { InstancedMesh2 } from "@three.ez/instanced-mesh";
import { Mesh, MeshLambertMaterial } from "three";
import { GLTF, GLTFLoader } from "three/examples/jsm/Addons.js";

preload(GLTFLoader, 'coin.glb')
export class Coin extends InstancedMesh2 {

  constructor() {
    const gltf = get<GLTF>("coin.glb");
    const geometry = (gltf.scene.children[0] as Mesh).geometry;

    super(geometry, new MeshLambertMaterial({ color: 'yellow' }), { createEntities: true });

    this.addInstances(1000, (obj, index) => {
      obj.position.set(Math.floor(Math.random() * 3) - 1, 4, -index);
      obj.scale.divideScalar(2);
    });

    this.computeBVH();
  }
}