import { getLoader, loadPending } from '@three.ez/asset-manager';
import { Main } from '@three.ez/main';
import { DRACOLoader, GLTFLoader } from 'three/examples/jsm/Addons.js';
import { GameScene } from './scene.js';
import { CollisionManager } from './collision-manager.js';

const main = new Main({ showStats: false });

const gltfLoader = getLoader(GLTFLoader);
gltfLoader.setDRACOLoader(new DRACOLoader().setDecoderPath('https://cdn.jsdelivr.net/npm/three@0.179.1/examples/jsm/libs/draco/gltf/'));
await loadPending();

const scene = new GameScene();

const collisionManager = new CollisionManager(scene); // we can put it in the scene obj instead
scene.on('afteranimate', (e) => collisionManager.update());

main.createView({ scene, camera: scene.camera, enabled: false });
