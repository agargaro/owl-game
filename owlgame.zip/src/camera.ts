import { PerspectiveCameraAuto } from "@three.ez/main";
import { Object3D, Vector3 } from "three";

export class GameCamera extends PerspectiveCameraAuto {
  public targetAnchor = new Vector3(0, 5, 5);
  public lookAtAnchor = new Vector3(0, 0, -3);

  constructor(target: Object3D) {
    super();

    const tempPosition = new Vector3();

    this.on('afteranimate', () => {
      tempPosition.copy(target.position);

      this.position.addVectors(tempPosition, this.targetAnchor);
      this.lookAt(tempPosition.add(this.lookAtAnchor));
    })
  }
}