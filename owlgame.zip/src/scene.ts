import { AmbientLight, DirectionalLight, FogExp2, Scene } from "three";
import { GameCamera } from "./camera.js";
import { Ground } from "./ground.js";
import { Owl } from "./owl.js";
import { Coin } from "./coin.js";

export class GameScene extends Scene {
  public owl = new Owl();
  public coin = new Coin();
  public camera = new GameCamera(this.owl);

  constructor() {
    super();
    this.fog = new FogExp2('gray', 0.05);

    const ambientLight = new AmbientLight();
    const directionalLight = new DirectionalLight();

    this.add(ambientLight, directionalLight, this.owl, this.coin);

    // test TODO add asset
    this.add(new Ground());
  }
}
