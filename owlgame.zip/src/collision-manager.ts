import { Box3 } from "three";
import { Coin } from "./coin.js";
import { Owl } from "./owl.js";
import { GameScene } from "./scene.js";

export class CollisionManager {
  private _owl: Owl;
  private _coin: Coin;

  constructor(scene: GameScene) {
    this._owl = scene.owl;
    this._coin = scene.coin;
  }

  public update(): void {
    const owlBox = new Box3().setFromObject(this._owl); // precompute it TODO

    this._coin.bvh.intersectBox(owlBox, (index) => {
      this._coin.removeInstances(index); // add events
      return true;
    });
  }
}